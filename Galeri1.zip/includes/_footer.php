<footer>
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>Copyright &copy; ◇ HARY-IT</p>
                </div>
            </div>
        </footer>
 </div> <!-- /container -->


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/myscript.js"></script>
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3703361972651186"
     crossorigin="anonymous"></script>
  </body>
</html>